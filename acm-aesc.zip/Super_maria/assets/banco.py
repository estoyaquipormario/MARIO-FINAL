import pyxel
pyxel.image(0).load(0,0, "mario_assets.pyxres")